package dao;

import db.DBContext;
import java.util.ArrayList;
import model.Shoe;

public class ShoeDAO extends DBContext {

    public ArrayList<Shoe> findAll() {
        // TODO: Implement findAll method - join Shoe, Category, and Staff tables, sorted by price ASC
        return null;
    }
}
