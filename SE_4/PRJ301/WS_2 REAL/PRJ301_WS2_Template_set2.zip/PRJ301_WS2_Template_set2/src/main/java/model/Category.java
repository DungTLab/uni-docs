package model;

public class Category {
    // TODO: Implement the Category model
}
