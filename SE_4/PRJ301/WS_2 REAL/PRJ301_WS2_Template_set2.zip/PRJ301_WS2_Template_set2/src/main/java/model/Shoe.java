package model;

public class Shoe {
    // TODO: Implement the Shoe model with extra fields for category name and creator name
}
