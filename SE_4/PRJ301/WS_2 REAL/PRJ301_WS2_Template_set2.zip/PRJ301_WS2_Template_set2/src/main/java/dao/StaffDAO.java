package dao;

import db.DBContext;
import model.Staff;

public class StaffDAO extends DBContext {

    public Staff login(String username, String password) {
        // TODO: Implement login method - query by username and MD5 password
        return null;
    }
}
