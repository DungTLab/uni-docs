package model;

public class Staff {
    // TODO: Implement the Staff model
}
